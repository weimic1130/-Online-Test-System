<?php
header("content-type:text/html;charset=utf-8");
//连接数据库
$link = mysqli_connect("localhost","root","root","bw123");
if (!$link) {
    die("连接失败: " . mysqli_connect_error());
}

$username=$_POST['username'];
$phone=$_POST['phone'];
  $sql="insert into user2(username,phone) values('$username','$phone')";
        $result=mysqli_query($link,$sql);
if(!$result)                                               // 判断数据是否成功插入进数据库
     {
        echo "<script>alert('提交失败！');location='index.html'</script>";
        }
        else
        {
          setcookie("username",$username,time()+60*60*24);
		  setcookie("phone",$phone,time()+60*60*24);
		  echo"<script>alert('马上将进入考试，每人只有一次考试机会哟');location='index1.html' </script>";
        }