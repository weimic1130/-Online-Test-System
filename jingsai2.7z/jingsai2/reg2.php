<?php
header("content-type:text/html;charset=utf-8");
//连接数据库
$link = mysqli_connect("localhost","root","root","bw123");
if (!$link) {
    die("连接失败: " . mysqli_connect_error());
}


$a1=$_POST['answer1'];
$a2=$_POST['answer2'];
$a3=$_POST['answer3'];
$a4=$_POST['answer4'];
$a5=$_POST['answer5'];
$a6=$_POST['answer6'];
$a7=$_POST['answer7'];
$a8=$_POST['answer8'];
$a9=$_POST['answer9'];
$a10=$_POST['answer10'];
$a11=$_POST['answer11'];
$a12=$_POST['answer12'];
$a13=$_POST['answer13'];
$a14=$_POST['answer14'];
$a15=$_POST['answer15'];
$a16=$_POST['answer16'];
$a17=$_POST['answer17'];
$a18=$_POST['answer18'];
$a19=$_POST['answer19'];
$a20=$_POST['answer20'];
$b1=implode("",$a16);
$b2=implode("",$a17);
$b3=implode("",$a18);
$b4=implode("",$a19);
$b5=implode("",$a20);

$resultion=array("$a1","$a2","$a3","$a4","$a5","$a6","$a7","$a8","$a9","$a10","$a11","$a12","$a13","$a14","$a15","$b1","$b2","$b3","$b4","$b5");
$outt=implode("",$resultion);

$c1 = $_COOKIE['username']; 
$c2 = $_COOKIE['phone'];


$correctresultion=array("c","d","a","c","c","c","d","a","a","d","a","d","b","a","b","abcd","bcd","c","b","ad");
$score=0;
for($i=0;$i<=14;$i++)
{if($resultion[$i]==$correctresultion[$i])
	{$score=$score+4;
	}

}
for($i=15;$i<=19;$i++)
{if($resultion[$i]==$correctresultion[$i])
	{$score=$score+8;
	}

}//算分数

    
        $sql="insert into user2(username,phone,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,b1,b2,b3,b4,b5,score) values('$c1','$c2','$a1','$a2','$a3','$a4','$a5','$a6','$a7','$a8','$a9','$a10','$a11','$a12','$a13','$a14','$a15','$b1','$b2','$b3','$b4','$b5','$score')";
        $result=mysqli_query($link,$sql);
        if(!$result)                                               // 判断数据是否成功插入进数据库
        {
         echo "<script>alert('提交失败！请检查是否未答完所有题目');location='index1.html';</script>";
        }
        else
        {
          echo"<script language=javascript>alert('提交成功！您的分数是 $score 分');location='index2.html';</script>";
        }

?>